The comment-stripped version is the one sent to Bram Moolenaar to be
bundled in Vim releases. It is manually updated when a new tagged release is made.
