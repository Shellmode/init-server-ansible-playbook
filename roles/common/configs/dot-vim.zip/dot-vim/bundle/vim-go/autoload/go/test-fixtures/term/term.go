package main

func main() {
	println("hello, world")
}
