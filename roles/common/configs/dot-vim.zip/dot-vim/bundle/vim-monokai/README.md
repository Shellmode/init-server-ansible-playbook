# Monokai for vim + iTerm2

[Original version](http://desintegr.free.fr/dokuwiki/doku.php?id=linux:vim:monokai)

This is a mod of the original Monokai for vim that works with console vim (with
at least 16 colors) provided you are also using the Monokai iTerm2 theme
provided.
