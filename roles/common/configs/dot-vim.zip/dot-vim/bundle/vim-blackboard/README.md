# Blackboard theme for vim and iTerm2

Thanks to [cloudhead's cotingale theme](https://github.com/cloudhead/dotfiles/blob/master/.vim/colors/cotingale.vim)
for giving some initial structure for this theme to build on top of.

This version of blackboard will work perfectly well with console vim (with at
least 16 colors) provided you use the accompanying iTerm2 theme provided.
