# vim-tomorrow-theme
Tomorrow Theme for Vim

This repository is deprecated and has been superseded by https://github.com/chriskempson/base16-vim
